import sys
import os
import json
import logging

import bpy
from io_three import exporter

sys.path.insert(0, os.path.dirname(__file__))
import constants

if __name__ == '__main__':
    print ('\n\nThree.js JSON command line exporter\n')
    default_path = bpy.data.filepath.replace('.blend', constants.EXTENSION)
    settings = constants.EXPORT_OPTIONS
    export_path = sys.argv[6]
    print ('\nExport file path:\n' + export_path + '\n')
    exporter.export_scene(export_path, settings)

