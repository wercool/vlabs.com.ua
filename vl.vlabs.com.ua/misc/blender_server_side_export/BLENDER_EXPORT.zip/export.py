import sys
import os
import json
import logging

import bpy
from io_three import exporter

sys.path.insert(0, os.path.dirname(__file__))
import constants

if __name__ == '__main__':
    print ('Three.js JSON command line exporter')
    default_path = bpy.data.filepath.replace('.blend', constants.EXTENSION)
#    settings = bpy.context.scene.get(constants.EXPORT_SETTINGS_KEY)
    settings = constants.EXPORT_OPTIONS
    export_path = os.path.dirname(__file__) + '/result/' + default_path[default_path.rindex('/') + 1:].replace('.blend', constants.EXTENSION)
    exporter.export_scene(export_path, settings)

